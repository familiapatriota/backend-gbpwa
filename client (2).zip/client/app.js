// =================================================================
// INSIRA A URL DO SEU BACKEND AQUI
const backendUrl = 'https://guriri-beach-api.onrender.com'; // Sua URL do Render
// =================================================================


// --- INICIALIZAÇÃO DO FIREBASE E VARIÁVEIS GLOBAIS ---
document.addEventListener('DOMContentLoaded', () => {
  if (typeof firebase === 'undefined' || !firebase.apps.length) {
    console.error('Firebase não está carregado.');
    return;
  }

  const auth = firebase.auth();
  const db = firebase.firestore();
  const page = window.location.pathname;

  if (page.includes('login.html') || page.endsWith('/gbpwa/')) {
    setupLoginPage();
  } else if (page.includes('index.html')) {
    setupMainPage();
  }

  function setupLoginPage() {
    // Código da página de login... (o mesmo de antes)
    const loginForm = document.getElementById('login-form');
    const signupForm = document.getElementById('signup-form');
    const showSignupLink = document.getElementById('show-signup');
    const showLoginLink = document.getElementById('show-login');

    if(showSignupLink) {
        showSignupLink.addEventListener('click', (e) => {
          e.preventDefault();
          loginForm.style.display = 'none';
          signupForm.style.display = 'block';
        });
    }
    if(showLoginLink) {
        showLoginLink.addEventListener('click', (e) => {
          e.preventDefault();
          signupForm.style.display = 'none';
          loginForm.style.display = 'block';
        });
    }
    document.getElementById('btn-login').addEventListener('click', handleLogin);
    document.getElementById('btn-signup').addEventListener('click', handleSignup);
  }

  function setupMainPage() {
    auth.onAuthStateChanged(user => {
      if (user) {
        document.getElementById('user-info').textContent = `Olá, ${user.email}`;
        fetchAndDisplayInvoices(user);
      } else {
        window.location.href = 'login.html';
      }
    });

    document.getElementById('btn-logout').addEventListener('click', () => {
      auth.signOut();
    });
  }

  async function handleSignup(e) {
      e.preventDefault();
      const name = document.getElementById('signup-name').value;
      const cpf = document.getElementById('signup-cpf').value;
      const email = document.getElementById('signup-email').value;
      const password = document.getElementById('signup-password').value;

      if (!name || !cpf || !email || !password) {
        showError('Por favor, preencha todos os campos.', 'signup-error');
        return;
      }

      try {
        const userCredential = await auth.createUserWithEmailAndPassword(email, password);
        const user = userCredential.user;
        await db.collection('users').doc(user.uid).set({ name, cpf, email });
        window.location.href = 'index.html';
      } catch (error) {
        console.error("Erro no cadastro:", error);
        showError(getFirebaseErrorMessage(error), 'signup-error');
      }
    }

    async function handleLogin(e) {
      e.preventDefault();
      const email = document.getElementById('login-email').value;
      const password = document.getElementById('login-password').value;

      if (!email || !password) {
        showError('Por favor, preencha todos os campos.', 'login-error');
        return;
      }

      try {
        await auth.signInWithEmailAndPassword(email, password);
        window.location.href = 'index.html';
      } catch (error) {
        console.error("Erro no login:", error);
        showError(getFirebaseErrorMessage(error), 'login-error');
      }
    }


  async function fetchAndDisplayInvoices(user) {
    if (!user) return;
    
    const loadingContainer = document.getElementById('loading-container');
    const invoicesSection = document.getElementById('invoices-section');

    loadingContainer.style.display = 'block';
    invoicesSection.style.display = 'none';

    try {
      const idToken = await user.getIdToken(true); // Força a atualização do token
      const response = await fetch(`${backendUrl}/api/mensalidades`, {
        headers: { 'Authorization': `Bearer ${idToken}` }
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Erro ${response.status}: ${errorText}`);
      }

      const invoices = await response.json();
      renderInvoices(invoices);

    } catch (error) {
      console.error("Erro ao buscar mensalidades:", error);
      const errorContainer = document.getElementById('vencidas-container');
      errorContainer.innerHTML = `<p class="error-message">Não foi possível buscar as mensalidades. Verifique sua conexão ou tente novamente mais tarde.</p>`;
    } finally {
        // Garante que o loading sempre desapareça
        loadingContainer.style.display = 'none';
        invoicesSection.style.display = 'block';
    }
  }
  
  function renderInvoices(invoices) {
      // Mesma função de antes
      const vencidasContainer = document.getElementById('vencidas-container');
      const apagarContainer = document.getElementById('apagar-container');
      const pagasContainer = document.getElementById('pagas-container');

      vencidasContainer.innerHTML = '';
      apagarContainer.innerHTML = '';
      pagasContainer.innerHTML = '';

      const hoje = new Date();
      hoje.setHours(0, 0, 0, 0);

      if (invoices.length === 0) {
          apagarContainer.innerHTML = "<p>Nenhuma mensalidade encontrada.</p>";
          return;
      }

      invoices.forEach(inv => {
        const dueDate = new Date(inv.dueDate);
        const invoiceElement = document.createElement('div');
        invoiceElement.className = 'invoice-card';

        let statusTag = '';
        if (inv.status === 'PAID') {
          statusTag = '<span class="tag tag-pago">PAGO</span>';
        } else if (dueDate < hoje) {
          statusTag = '<span class="tag tag-vencido">VENCIDA</span>';
        }

        invoiceElement.innerHTML = `
          <div class="invoice-details">
              <p class="invoice-value">R$ ${inv.value.toFixed(2).replace('.', ',')}</p>
              <p class="invoice-due-date">Vencimento: ${new Date(inv.dueDate).toLocaleDateString('pt-BR')}</p>
          </div>
          <div class="invoice-actions">
              ${statusTag}
              <a href="${inv.invoiceUrl || inv.bankSlipUrl}" target="_blank" class="btn-primary">Ver Boleto / Pagar</a>
          </div>
        `;

        if (inv.status === 'PAID' || inv.status === 'CONFIRMED') {
          pagasContainer.appendChild(invoiceElement);
        } else if (dueDate < hoje) {
          vencidasContainer.appendChild(invoiceElement);
        } else {
          apagarContainer.appendChild(invoiceElement);
        }
      });
      if(vencidasContainer.childElementCount === 0) vencidasContainer.innerHTML = "<p>Nenhuma mensalidade vencida.</p>";
      if(apagarContainer.childElementCount === 0) apagarContainer.innerHTML = "<p>Nenhuma mensalidade a pagar.</p>";
      if(pagasContainer.childElementCount === 0) pagasContainer.innerHTML = "<p>Nenhuma mensalidade paga.</p>";
    }

  function showError(message, elementId) {
    const errorElement = document.getElementById(elementId);
    errorElement.textContent = message;
    errorElement.style.display = 'block';
  }
  
  function getFirebaseErrorMessage(error) {
    switch (error.code) {
        case 'auth/user-not-found':
        case 'auth/wrong-password':
        case 'auth/invalid-credential':
            return 'E-mail ou senha incorretos.';
        case 'auth/email-already-in-use':
            return 'Este e-mail já está em uso.';
        case 'auth/weak-password':
            return 'A senha deve ter no mínimo 6 caracteres.';
        case 'permission-denied':
            return 'Erro de permissão. Contate o suporte.';
        default:
            return 'Ocorreu um erro inesperado. Tente novamente.';
    }
  }

});

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/service-worker.js').then(registration => {
      console.log('ServiceWorker registrado: ', registration.scope);
    }).catch(err => {
      console.log('Falha no registro do ServiceWorker: ', err);
    });
  });
}

